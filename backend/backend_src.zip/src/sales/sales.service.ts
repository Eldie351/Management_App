import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';
import { CreateSaleDto } from './dto/create-sale.dto';
import { MovementType, UserRole } from '@prisma/client';

@Injectable()
export class SalesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly notificationsService: NotificationsService,
  ) {}

  async createSale(userId: number, dto: CreateSaleDto) {
    if (!dto.items || dto.items.length === 0) {
      throw new BadRequestException('Le panier ne peut pas être vide.');
    }

    // 1. Récupérer l'utilisateur avec TOUS ses magasins associés (assigned, owned, assignments)
    const currentUser = await this.prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        role: true,
        assignedStoreId: true,
        ownedStores: { select: { id: true } },
        storeAssignments: { select: { storeId: true } },
      },
    });

    if (!currentUser) {
      throw new NotFoundException('Utilisateur introuvable.');
    }

    // Sécurité : Vérification dynamique des magasins autorisés si non-ADMIN
    if (currentUser.role !== UserRole.ADMIN) {
      const allowedStoreIds = [
        currentUser.assignedStoreId,
        ...(currentUser.ownedStores?.map((s) => s.id) ?? []),
        ...(currentUser.storeAssignments?.map((sa) => sa.storeId) ?? []),
      ].filter((id): id is number => Boolean(id));

      if (!allowedStoreIds.includes(dto.storeId)) {
        throw new ForbiddenException(
          "Vous n'êtes pas autorisé à effectuer une vente dans ce magasin.",
        );
      }
    }

    // Transaction atomique : tout réussit ou tout est annulé
    return await this.prisma.$transaction(async (tx) => {
      // 2. Vérifier que le magasin existe et possède les informations obligatoires
      const store = await tx.store.findUnique({
        where: { id: dto.storeId },
        select: { id: true, name: true, location: true, phone: true, currency: true },
      });

      if (!store) {
        throw new NotFoundException('Magasin introuvable.');
      }

      if (!store.location || !store.phone) {
        throw new BadRequestException(
          'Les informations du magasin sont incomplètes. Veuillez renseigner l’adresse et le téléphone du magasin.',
        );
      }

      // 3. Récupération groupée des produits en base de données
      const productIds = dto.items.map((item) => item.productId);
      const dbProducts = await tx.product.findMany({
        where: { id: { in: productIds } },
      });

      const productMap = new Map(dbProducts.map((p) => [p.id, p]));

      let calculatedTotalAmount = 0;

      const verifiedItems: Array<{
        productId: number;
        quantity: number;
        unitPrice: number;
        total: number;
      }> = [];

      // 3. Validation et calcul sécurisé basé sur les données DB
      for (const item of dto.items) {
        const product = productMap.get(item.productId);

        if (!product || product.deletedAt) {
          throw new NotFoundException(
            `Produit ID ${item.productId} introuvable ou archivé.`,
          );
        }

        if (product.storeId !== dto.storeId) {
          throw new BadRequestException(
            `Le produit "${product.name}" n'appartient pas au magasin spécifié.`,
          );
        }

        if (product.quantity < item.quantity) {
          throw new BadRequestException(
            `Stock insuffisant pour "${product.name}". Disponible: ${product.quantity}, Demandé: ${item.quantity}`,
          );
        }

        const itemUnitPrice = Number(product.sellingPrice);
        const itemTotal = itemUnitPrice * item.quantity;
        calculatedTotalAmount += itemTotal;

        verifiedItems.push({
          productId: item.productId,
          quantity: item.quantity,
          unitPrice: itemUnitPrice,
          total: itemTotal,
        });
      }

      // 4. Génération d'un numéro de facture unique en séquence par magasin et par année
      const year = new Date().getFullYear();
      const yearStart = new Date(`${year}-01-01T00:00:00.000Z`);
      const sequenceCount = await tx.sale.count({
        where: {
          storeId: dto.storeId,
          createdAt: { gte: yearStart },
        },
      });
      const sequenceNumber = String(sequenceCount + 1).padStart(4, '0');
      const invoiceNumber = `${year}-${dto.storeId}-${sequenceNumber}`;

      // 5. Enregistrement de la vente
      const sale = await tx.sale.create({
        data: {
          invoiceNumber,
          totalAmount: calculatedTotalAmount,
          paymentMethod: dto.paymentMethod,
          storeId: dto.storeId,
          userId,
          items: {
            create: verifiedItems.map((item) => ({
              productId: item.productId,
              quantity: item.quantity,
              unitPrice: item.unitPrice,
              total: item.total,
            })),
          },
        },
        include: {
          items: {
            include: { product: true },
          },
          user: { select: { id: true, name: true, email: true } },
          store: true,
        },
      });

      // 6. Mise à jour des stocks et enregistrement des mouvements
      for (const item of verifiedItems) {
        await tx.product.update({
          where: { id: item.productId },
          data: {
            quantity: { decrement: item.quantity },
          },
        });

        await tx.stockMovement.create({
          data: {
            quantity: -item.quantity,
            type: MovementType.SALE,
            note: `Vente ${sale.invoiceNumber}`,
            productId: item.productId,
            userId,
            storeId: dto.storeId,
          },
        });
      }

      // 7. Créer une notification pour informer managers/admins du magasin
      try {
        await this.notificationsService.create(
          dto.storeId,
          'Nouvelle vente',
          `Vente ${invoiceNumber} enregistrée — montant ${calculatedTotalAmount.toFixed(2)}`,
          tx,
        );
      } catch (e) {
        // Ignorer en cas d'erreur de notification
      }

      return sale;
    });
  }

  async findAllByStore(storeId: number) {
    return this.prisma.sale.findMany({
      where: { storeId },
      include: {
        items: { include: { product: true } },
        user: { select: { id: true, name: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: number) {
    const sale = await this.prisma.sale.findUnique({
      where: { id },
      include: {
        items: { include: { product: true } },
        user: { select: { id: true, name: true, email: true } },
        store: true,
      },
    });

    if (!sale) {
      throw new NotFoundException(`Facture #${id} introuvable.`);
    }

    return sale;
  }

  async deleteSale(id: number, actorUserId: number) {
    const sale = await this.findOne(id);

    return this.prisma.$transaction(async (tx) => {
      for (const item of sale.items) {
        await tx.product.update({
          where: { id: item.productId },
          data: {
            quantity: { increment: item.quantity },
          },
        });

        await tx.stockMovement.create({
          data: {
            quantity: item.quantity,
            type: MovementType.ADJUSTMENT,
            note: `Annulation de facture ${sale.invoiceNumber}`,
            productId: item.productId,
            userId: actorUserId,
            storeId: sale.storeId,
          },
        });
      }

      await tx.saleItem.deleteMany({ where: { saleId: sale.id } });
      return tx.sale.delete({ where: { id: sale.id } });
    });
  }
}